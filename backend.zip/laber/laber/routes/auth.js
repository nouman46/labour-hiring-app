import express from 'express';
import laborSignup from '../models/laborSignup.js';
import CustomerSignup from '../models/CustomerSignup.js';
import authMiddleware from '../middleware/authTokenValidation.js';
import { login, createUser, laborStats, CcreateUser, CLogin, getUser, getCustomer, getAllUser } from '../controllers/index.js';

const router = express.Router();

router.post("/login", login);
router.post("/createUser", createUser); // Use POST for creating a user
router.post("/laborStats", laborStats);
router.post("/CcreateUser", CcreateUser);
router.post("/CLogin", CLogin);
router.get("/getUser", authMiddleware(laborSignup), getUser);
router.get("/getCustomer", authMiddleware(CustomerSignup), getCustomer);
router.get("/getAllUser", authMiddleware(CustomerSignup), getAllUser);

export default router;
