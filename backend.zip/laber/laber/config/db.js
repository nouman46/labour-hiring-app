import mongoose from "mongoose";

const DB = () => { 
    try {
        mongoose.set("strictQuery", false);

        mongoose.connect("mongodb+srv://3idiots:strongpassword3@3idiots.y1z6j4z.mongodb.net/?retryWrites=true&w=majority&appName=3idiots");

        mongoose.connection.on("connected", () => {
            console.info(`MongoDB Connected...`);
        });

        mongoose.connection.on("error", (error) => {
            console.error("Mongoose connection error:", error);
        });

        mongoose.connection.on("disconnected", () => {
            console.warn("Mongodb disconnected...");
        });

        mongoose.connection.on("reconnected", () => {
            console.warn("Mongodb reconnected successfully.");
        });
    } catch (error) {
        console.log("error", `${error.message}`);
        process.exit(1);
    }
};

export default DB;
