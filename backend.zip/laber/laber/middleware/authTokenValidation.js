import pkg from 'jsonwebtoken';
const { verify } = pkg;

const authMiddleware = (model) => {
    const authHandler = async (req, res, next) => {
        try {
            const authorization = req.headers.authorization;
            if (!authorization) {
                return res.status(400).send({ message: "auth token is missing" });
            }
            const token = authorization.split(" ")[1];
            console.log(token);
            const decoded = verify(token, "mysecretkey");
            if (!decoded) {
                return res.status(401).send({ error: "Please provide valid token." });
            }
            const user = await model.findOne({ _id: decoded._id }).select("-password -__v");
            req.user = user;
            next();
        } catch (error) {
            return res.status(401).send({ error: "Please provide valid token." });
        }
    };
    return authHandler;
};
export default authMiddleware;
