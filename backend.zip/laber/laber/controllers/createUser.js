import laborSignup from "../models/laborSignup.js";
// import { EMAIL_REGEX, PHONE_NUMBER_REGEX, } from "../../constants/regex.js";

const EMAIL_REGEX = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
//const PHONE_NUMBER_REGEX = /^\+923[0-9]{9}$/;

const createUser = async (req, res) => {
    const { name, email, phoneNumber, cnic, password, confirmPassword, city} = req.body;

    // Check if required fields are missing
    if (!name || !email || !phoneNumber || !cnic || !password || !confirmPassword || !city) {
        return res.status(400).json({ error: "Required fields are missing" });
    }
    if (!email.match(EMAIL_REGEX)) {
        return res.status(400).json({ error: "Invalid email address" });
    }
   
    // Check if passwords match
    if (password !== confirmPassword) {
        return res.status(400).json({ error: "Passwords do not match" });
    }

    try {
        // Check if the user already exists
        const existingUser = await laborSignup.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: "User already exists" });
        }
   
        // Create the user
        const user = await laborSignup.create({ name, email, phoneNumber, cnic, password, city });

        // Return success response
        res.status(201).json({ message: "User created successfully", user:{name, email, phoneNumber, cnic, city}, token: user.generateAuthToken() });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error:error.message});
    }
};

export default createUser;
