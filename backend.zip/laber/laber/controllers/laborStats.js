import laborSignup from "../models/laborSignup.js";
import lStats from "../models/LStats.js";

const laborStats = async (req, res) => {
    try {
        // Fetch email from laborSignup collection in MongoDB
        const laborUser = await laborSignup.findOne({}); // Assuming you want to fetch the first labor user found

        // If labor user is not found or email is missing, return an error
        if (!laborUser || !laborUser.email) {
            return res.status(404).json({ error: "Labor user email not found" });
        }

        const { price, experience } = req.body; // Assuming price and experience are provided in the request body
        const priceNumber = Number(price);
        const experienceNumber = Number(experience);

        // Validate price and experience
        if (isNaN(priceNumber) || priceNumber <= 100 || isNaN(experienceNumber) || experienceNumber <= 0) {
            return res.status(400).json({ error: "Invalid price or experience" });
        }

        // Create labor statistics associated with the labor user
        const laborStatsData = {
            price: priceNumber,
            experience: experienceNumber,
            laborEmail: laborUser.email // Save labor email along with labor statistics
        };

        const laborStats = await lStats.create(laborStatsData);

        // Return success response without including email separately
        res.status(201).json({ message: "Labor statistics created successfully", laborStats });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

export default laborStats;
