import login from './login.js';
import createUser from './createUser.js';
import laborStats from './laborStats.js';
import CcreateUser from './CcreateUser.js';
import CLogin from './CLogin.js';
import getUser from './getUser.js';
import getCustomer from './getCustomer.js';
import getAllUser from './getAllUser.js';

export {
    login,
    createUser,
    laborStats,
    CcreateUser,
    CLogin,
    getUser,
    getCustomer,
    getAllUser,
};