import express from 'express';
import CustomerSignup from '../models/CustomerSignup.js';

const router = express.Router();

router.post('/CLogin', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ success: false, message: "Required fields are missing" });
        }

        const user = await CustomerSignup.findOne({ email });

        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        if (password !== user.password) {
            return res.status(400).json({ success: false, message: "Incorrect email or password" });
        }
       const token = user.generateAuthToken();
       res.status(200).json({ success: true, message: "User login successful", user: { name: user.name, email: user.email, phoneNumber: user.phoneNumber, city: user.city, image: user.image }, token });
    } catch (error) {
        console.error("Error occurred:", error);
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
});

export default router;
