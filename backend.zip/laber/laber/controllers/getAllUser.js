import laborSignup from "../models/laborSignup.js";

const getAllUser = async (req, res) => {
    try {
        const { user } = req;
        const users = await laborSignup.find();
        if(!users) {
            return res.status(404).json({ error: "No users found" });
        }
        return res.status(200).json({ message: "Users fetched successfully", users });
    } catch (error) {
        console.log("error", `${error.message}`);
        return res.status(500).json({ error: "Internal server error" });
    }
};
export default getAllUser;
