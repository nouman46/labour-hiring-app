const getCustomer = async (req, res) => {
    try {
        const { user } = req;
        return res.status(200).json({ message: "User fetched successfully", user });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
}
export default getCustomer;
