import CustomerSignup from "../models/CustomerSignup.js";

const CcreateUser = async (req, res) => {
    const { name, email, phoneNumber, password, confirmPassword, image } = req.body;

    // Check if required fields are missing
    if (!name || !email || !phoneNumber || !password || !confirmPassword) {
        return res.status(400).json({ error: "Required fields are missing" });
    }

    // Check if passwords match
    if (password !== confirmPassword) {
        return res.status(400).json({ error: "Passwords do not match" });
    }

    try {
        // Check if the user already exists
        const existingUser = await CustomerSignup.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: "User already exists" });
        }

        // Create the user
        const user = await CustomerSignup.create({ name, email, phoneNumber, password, image });
        const token = user.generateAuthToken();
        // Return success response
        res.status(201).json({ message: "User created successfully", user, token });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

export default CcreateUser;
