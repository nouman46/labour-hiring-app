import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    price: {
        type:String,
    },
    experience: {
        type:String,
        
    },
    laborEmail: {
        type: String, // Assuming email is a string
        required: true
    }

})

const lStats = mongoose.model('lstats', userSchema);

export default lStats;