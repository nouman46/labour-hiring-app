import mongoose from "mongoose";
import jwt from "jsonwebtoken";

const LSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
    },
    phoneNumber: {
        type: String,
       // unique: true,
        required: true,
    },
    cnic: {
        type: String,
        //unique: true,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    city: {
        type: String,
        required: true,
    },
    
}, {
    timestamps: true,
});

LSchema.methods.generateAuthToken = function () {
    try {
        const token = jwt.sign({ _id: this._id }, "mysecretkey");
        return token;
    } catch (err) {
        throw err;
    }
};

const laborSignup = mongoose.model('labor', LSchema);

export default laborSignup;
