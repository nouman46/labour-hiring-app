import mongoose from "mongoose";
import jwt from "jsonwebtoken";

const LSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
    },
    phoneNumber: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    image: {
        type: String,
    },
}, {
    timestamps: true,
});

LSchema.methods.generateAuthToken = function () {
    try {
        const token = jwt.sign({ _id: this._id }, "mysecretkey");
        return token;
    } catch (err) {
        throw err;
    }
}

const CustomerSignup = mongoose.model('customer', LSchema);

export default CustomerSignup;
